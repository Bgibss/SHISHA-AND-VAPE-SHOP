# SHISHA AND VAPE SHOP

Static website ready for GitHub Pages.

## Publish with GitHub Pages
1. Upload the contents of this folder to the root of your GitHub repository.
2. Make sure `index.html` is in the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose your main branch and `/ (root)`.
5. Save and open the generated GitHub Pages address.
