SHISHA AND VAPE SHOP — PRODUCT CATALOGUE

HOW TO ADD A PRODUCT
1. Put the product photo inside the products/ folder.
2. Open products.js.
3. Copy one product entry and change name, category, price, image and description.
4. Save and redeploy the website.

PRICE
Products currently show “Price on request” because prices were not supplied with the photos.
Once you give the prices, replace that text with the actual price.

IMPORTANT
The website already has an adult-age gate. Keep product information factual and comply with applicable laws and platform rules.
