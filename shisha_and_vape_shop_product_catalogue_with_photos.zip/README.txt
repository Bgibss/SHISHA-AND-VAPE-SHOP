# SHISHA AND VAPE SHOP — Mobile Website

A lightweight, responsive static website designed for iPhone/Android screens.

## Product catalogue
The site now includes a mobile-friendly product catalogue with:
- product photos
- product name
- category
- price
- description
- search
- category filters
- WhatsApp enquiry/order buttons

Products are managed from `products.js`. Product photos go in the `products/` folder.

Example entry:
{
  name: "Example Product",
  category: "Vapes",
  price: "$15",
  image: "products/example-product.jpg",
  description: "Short description",
  featured: true
}

For future updates, add the product photo to `products/` and add one entry to `products.js`, then redeploy the website.

## Before publishing
1. Replace the Google Maps search links with exact map pins if available.
2. Confirm opening hours and update the site if needed.
3. Confirm that the website and advertising destination comply with applicable laws and platform policies.
4. Host the files on the chosen Cloudflare deployment and connect your domain.

## Contact numbers
0777711211
0776344999

## Phone number cleanup
Each shop's phone number is shown once in its location card. The contact section uses shop-specific WhatsApp buttons, and the mobile sticky bar no longer repeats one shop's number.
