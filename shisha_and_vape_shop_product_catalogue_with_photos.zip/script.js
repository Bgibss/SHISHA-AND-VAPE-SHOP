const ageGate = document.getElementById("ageGate");
const enterBtn = document.getElementById("enterBtn");
const leaveBtn = document.getElementById("leaveBtn");
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

if (localStorage.getItem("sv_age_confirmed") === "yes") {
  ageGate.classList.add("hidden");
}

enterBtn.addEventListener("click", () => {
  localStorage.setItem("sv_age_confirmed", "yes");
  ageGate.classList.add("hidden");
});

leaveBtn.addEventListener("click", () => {
  document.body.innerHTML = `
    <main style="min-height:100vh;display:grid;place-items:center;padding:30px;text-align:center;background:#080808;color:#fff;font-family:Arial,sans-serif">
      <div><h1>Thanks for visiting.</h1><p style="color:#aaa">This website is intended for adults of legal age only.</p></div>
    </main>`;
});

menuBtn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
});

document.querySelectorAll("#nav a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

// Product catalogue
const productGrid = document.getElementById("productGrid");
const productSearch = document.getElementById("productSearch");
const categoryFilters = document.getElementById("categoryFilters");
const emptyCatalogue = document.getElementById("emptyCatalogue");

let activeCategory = "All";

function whatsappUrl(number, productName) {
  const message = encodeURIComponent(`Hello SHISHA AND VAPE SHOP, I'd like to enquire about ${productName}. Is it available?`);
  return `https://wa.me/${number}?text=${message}`;
}

function renderFilters(products) {
  const categories = ["All", ...new Set(products.map(p => p.category).filter(Boolean))];
  categoryFilters.innerHTML = categories.map(category => `
    <button class="filter-btn ${category === activeCategory ? "active" : ""}" data-category="${category}">${category}</button>
  `).join("");

  categoryFilters.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      activeCategory = btn.dataset.category;
      renderCatalogue();
    });
  });
}

function renderCatalogue() {
  const products = Array.isArray(PRODUCTS) ? PRODUCTS : [];
  renderFilters(products);
  const query = (productSearch?.value || "").trim().toLowerCase();
  const visible = products.filter(product => {
    const categoryMatch = activeCategory === "All" || product.category === activeCategory;
    const searchText = `${product.name || ""} ${product.category || ""} ${product.description || ""}`.toLowerCase();
    return categoryMatch && searchText.includes(query);
  });

  productGrid.innerHTML = visible.map(product => {
    const safeName = String(product.name || "Product");
    const image = product.image
      ? `<img class="product-image" src="${product.image}" alt="${safeName}" loading="lazy">`
      : `<div class="product-image-placeholder">Product photo</div>`;
    return `
      <article class="product-card">
        ${image}
        <div class="product-info">
          <div class="product-category">${product.category || "Product"}</div>
          <h3 class="product-name">${safeName}</h3>
          ${product.description ? `<p class="product-description">${product.description}</p>` : ""}
          ${product.price ? `<div class="product-price">${product.price}</div>` : ""}
          <div class="product-actions">
            <a class="btn btn-gold" href="${whatsappUrl("263777711211", safeName)}" target="_blank" rel="noopener">Order on WhatsApp</a>
          </div>
        </div>
      </article>`;
  }).join("");

  emptyCatalogue.hidden = products.length > 0 || query.length > 0;
  if (products.length > 0 && visible.length === 0) {
    emptyCatalogue.hidden = false;
    emptyCatalogue.innerHTML = `<strong>No products found.</strong><span>Try another search or category.</span>`;
  } else if (products.length === 0) {
    emptyCatalogue.hidden = false;
    emptyCatalogue.innerHTML = `<strong>Product catalogue coming soon.</strong><span>WhatsApp us for current stock and availability.</span>`;
  }
}

if (productGrid && productSearch && categoryFilters) {
  productSearch.addEventListener("input", renderCatalogue);
  renderCatalogue();
}
