const PRODUCTS = [
  {
    name: "VOLTz Vape Range",
    category: "Vapes",
    price: "Price on request",
    image: "products/voltz-vape-range.jpeg",
    description: "VOLTz vape range shown in-store. Ask us for available puff counts and flavours.",
    featured: true
  },
  {
    name: "Lifbar Plus — Strawberry Jam",
    category: "Vapes",
    price: "Price on request",
    image: "products/lifbar-plus-strawberry-jam.jpeg",
    description: "Lifbar Plus with 20K Plus Mode / 30K Regular Mode shown on the pack.",
    featured: true
  },
  {
    name: "Tornado 25K — Energy Drink",
    category: "Vapes",
    price: "Price on request",
    image: "products/tornado-25000-energy-drink.jpeg",
    description: "Tornado 25K disposable vape — Energy Drink flavour.",
    featured: true
  },
  {
    name: "Nasty Bar 16K — Pineapple Ice",
    category: "Vapes",
    price: "Price on request",
    image: "products/nasty-bar-pineapple-ice.jpeg",
    description: "Nasty Bar 16,000 puff Pineapple Ice flavour.",
    featured: true
  },
  {
    name: "Shisha — Blue & Purple",
    category: "Shisha & Hookahs",
    price: "Price on request",
    image: "products/shisha-pair-blue-purple.jpeg",
    description: "Colourful shisha setups available in-store. Ask about available colours and styles.",
    featured: true
  },
  {
    name: "Runfree 40K — Blueberry Ice",
    category: "Vapes",
    price: "Price on request",
    image: "products/runfree-40000-blueberry-ice.jpeg",
    description: "Runfree rechargeable vape, 40,000 puffs, Blueberry Ice shown.",
    featured: true
  },
  {
    name: "Anlya Prefilled Pod 14K",
    category: "Vapes",
    price: "Price on request",
    image: "products/anlya-14000-prefilled-pod.jpeg",
    description: "Anlya prefilled pod, up to 14,000 puffs, with multiple flavours shown.",
    featured: true
  },
  {
    name: "Shisha Display Range",
    category: "Shisha & Hookahs",
    price: "Price on request",
    image: "products/shisha-display-range.jpeg",
    description: "A selection of shisha and hookah styles available in-store.",
    featured: true
  },
  {
    name: "Nasty Pod 16K Range",
    category: "Vapes",
    price: "Price on request",
    image: "products/nasty-pod-16000-range.jpeg",
    description: "Nasty Pod range with multiple flavours shown. Ask for current flavour availability.",
    featured: true
  }
];
